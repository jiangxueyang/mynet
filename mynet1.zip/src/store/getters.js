export default{
	userName :({my}) => my.info.name?my.info.name:'world'
}