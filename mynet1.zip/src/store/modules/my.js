export default{
	state:{ //变量
		info:''
	},
	actions:{
		async GET_INFO ({commit},data){
			if(data.name){
				commit('SET_USER', data);
			}
		}
	},
	mutations:{
		SET_USER (state, d) {
			state.info = d;
		},
	}
}